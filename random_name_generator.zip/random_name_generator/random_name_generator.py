import sys, random
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QCheckBox, QRadioButton, QButtonGroup
from PyQt5.QtGui import QIcon, QFontDatabase, QFont
from PyQt5.QtCore import Qt
from random_words import adjectives, nouns

class Random_Name_Generator(QWidget):
    def __init__(self):
        super().__init__()

        # LABELS
        self.header_label = QLabel("Random Name Generator", self)
        self.name_label = QLabel(self)
        self.copy_label = QLabel(self)

        # PUSH BUTTONS
        self.name_generate = QPushButton("Generate", self)
        self.copy_name = QPushButton("Copy", self)

        # RADIO BUTTONS (Parameters)
        self.no_space = QRadioButton("No Space", self)
        self.space = QRadioButton("Space", self)
        self.underscore = QRadioButton("Underscore", self)
        self.dot = QRadioButton("Dot", self)

        # BUTTON GROUP (Parameters)
        self.parameters = QButtonGroup(self)

        self.initUI()

    def initUI(self):
        self.setWindowTitle("Random Name Generator")
        self.setWindowIcon(QIcon("letter-a.png"))

        # ALIGNMENTS
        self.header_label.setAlignment(Qt.AlignCenter)
        self.name_label.setAlignment(Qt.AlignCenter)
        self.copy_label.setAlignment(Qt.AlignCenter)

        # LAYOUTS
        vbox = QVBoxLayout()
        vbox.addWidget(self.header_label)
        vbox.addWidget(self.name_label)
        vbox.addWidget(self.copy_label)

        hbox = QHBoxLayout()
        hbox.addWidget(self.name_generate)
        hbox.addWidget(self.copy_name)

        hbox2 = QHBoxLayout()
        hbox2.addWidget(self.no_space)
        hbox2.addWidget(self.space)
        hbox2.addWidget(self.underscore)
        hbox2.addWidget(self.dot)

        vbox.addLayout(hbox)
        vbox.addLayout(hbox2)
        self.setLayout(vbox)

        # STYLE SHEET
        self.setStyleSheet("""
            QRadioButton{
                font-size: 15px;
            }
            
            QPushButton{
                font-size: 20px;
            }
        """)

        # BUTTON CONNECT TO FUNCTION
        self.name_generate.clicked.connect(self.generate_word)
        self.copy_name.clicked.connect(self.copy_random_generated_name)

        # ADD BUTTON TO BUTTON GROUP
        self.parameters.addButton(self.no_space)
        self.parameters.addButton(self.space)
        self.parameters.addButton(self.underscore)
        self.parameters.addButton(self.dot)

    def generate_word(self):
        # ADJECTIVES AND NOUNS FROM RANDOM WORDS PYTHON FILE
        adjective = random.choice(adjectives)
        noun = random.choice(nouns)

        # PARAMETERS LOGIC
        if self.no_space.isChecked():
            self.random_name = adjective + noun
        elif self.space.isChecked():
            self.random_name = adjective + " " + noun
        elif self.underscore.isChecked():
            self.random_name = adjective + "_" + noun
        elif self.dot.isChecked():
            self.random_name = adjective + "." + noun
        else:
            self.name_label.setText("Please select a format first.")
            self.copy_label.setText("")
            return 

        # SET TEXT
        self.name_label.setText(self.random_name)
        self.copy_label.setText("")

    def copy_random_generated_name(self):
        # COPY TO CLIPBOARD
        clipboard = QApplication.clipboard()
        text = self.name_label.text()
        clipboard.setText(text)
        self.copy_label.setText("Password has been copied.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    random_name_generator = Random_Name_Generator()
    random_name_generator.show()
    sys.exit(app.exec_())